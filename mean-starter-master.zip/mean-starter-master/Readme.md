### MEAN

> **M**ongo **E**xpress **A**ngular **N**ode

### How to get a copy of the code

```
cd desktop
git clone https://github.com/ammonk/mean-starter.git
```

### How to run

```
npm install
npm run dev
```

### How To Make From Scratch
