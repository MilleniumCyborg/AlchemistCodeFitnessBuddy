export class Fruit {
  id: number;
  name: string;
}
